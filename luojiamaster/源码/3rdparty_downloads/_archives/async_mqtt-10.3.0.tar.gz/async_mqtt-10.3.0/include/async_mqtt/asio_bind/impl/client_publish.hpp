// Copyright Takatoshi Kondo 2022
//
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(ASYNC_MQTT_ASIO_BIND_IMPL_CLIENT_PUBLISH_HPP)
#define ASYNC_MQTT_ASIO_BIND_IMPL_CLIENT_PUBLISH_HPP

#include <boost/hana/tuple.hpp>
#include <boost/hana/back.hpp>
#include <boost/hana/drop_back.hpp>
#include <boost/hana/unpack.hpp>

#include <async_mqtt/asio_bind/client.hpp>
#include <async_mqtt/asio_bind/impl/client_impl.hpp>
#include <async_mqtt/util/log.hpp>

namespace async_mqtt {

namespace hana = boost::hana;

namespace detail {

template <protocol_version Version, typename NextLayer>
template <typename CompletionToken>
auto
client_impl<Version, NextLayer>::async_publish(
    this_type_sp impl,
    error_code ec,
    std::optional<typename client_type::publish_packet> packet,
    CompletionToken&& token
) {
    BOOST_ASSERT(impl);
    if (packet) {
        ASYNC_MQTT_LOG("mqtt_api", info)
            << ASYNC_MQTT_ADD_VALUE(address, impl.get())
            << *packet;
    }
    auto exe = impl->get_executor();
    return
        as::async_initiate<
            CompletionToken,
            void(error_code, typename client_type::pubres_type)
        >(
            [](
                auto handler,
                this_type_sp impl,
                error_code ec,
                std::optional<typename client_type::publish_packet> packet
            ) {
                async_publish_impl(
                    force_move(impl),
                    ec,
                    force_move(packet),
                    force_move(handler)
                );
            },
            token,
            force_move(impl),
            ec,
            force_move(packet)
        );
}

} // namespace detail

template <protocol_version Version, typename NextLayer>
template <typename... Args>
auto
client<Version, NextLayer>::async_publish(Args&&... args) {
    BOOST_ASSERT(impl_);
    if constexpr (std::is_constructible_v<publish_packet, decltype(std::forward<Args>(args))...>) {
        try {
            return impl_type::async_publish(
                impl_,
                error_code{},
                publish_packet{std::forward<Args>(args)...}
            );
        }
        catch (system_error const& se) {
            return impl_type::async_publish(
                impl_,
                se.code(),
                std::nullopt
            );
        }
    }
    else {
        auto all = hana::make_tuple(std::forward<Args>(args)...);
        auto back = hana::at_c<sizeof...(Args) - 1>(force_move(all));
        return hana::unpack(
            hana::drop_back(force_move(all), hana::size_c<1>),
            [this, back = force_move(back)](auto&&... rest_args) mutable {
                    static_assert(
                        std::is_constructible_v<
                            publish_packet,
                            decltype(rest_args)...
                        >,
                        "publish_packet is not constructible"
                    );
                    try {
                        return impl_type::async_publish(
                            impl_,
                            error_code{},
                            publish_packet{std::forward<decltype(rest_args)>(rest_args)...},
                            force_move(back)
                        );
                    }
                    catch (system_error const& se) {
                        return impl_type::async_publish(
                            impl_,
                            se.code(),
                            std::nullopt,
                            force_move(back)
                        );
                    }
                }
            );
    }
}

} // namespace async_mqtt

#if !defined(ASYNC_MQTT_SEPARATE_COMPILATION)
#include <async_mqtt/asio_bind/impl/client_publish.ipp>
#endif // !defined(ASYNC_MQTT_SEPARATE_COMPILATION)

#endif // ASYNC_MQTT_ASIO_BIND_IMPL_CLIENT_PUBLISH_HPP
